﻿using BepInEx;
using GorillaExtensions;
using System;
using TMPro;
using UnityEngine;

namespace GorillaTag.MOTD
{
    [BepInPlugin("m", "ccdBiblev2", "1.0.1")]
    public class MotdBiblev2 : BaseUnityPlugin
    {
        private TextMeshPro txt;
        private float colorTimer = 0f;
        private readonly Color startColor = new Color(0.5f, 0f, 1f);
        private readonly Color endColor = new Color(0.8f, 0.6f, 1f);

        private readonly string[] verses = new string[]
        {
    "I'd like to take you to the movies but they don't let you bring your own snacks in.",
    "No pen, no paper but you still draw my attention.",
    "All the good pick up lines are taken but you aren't.",
    "Excuse me while I delete my dating apps.",
    "This must be a museum because you're a work of art.",
    "Are you WiFi? Because I feel a connection.",
    "I'm not even playing cards but somehow I pulled a Queen.",
    "You must be a dog person because you look fetching.",
    "I didn't even have to run to catch these butterflies.",
    "I'm lost. Can you give me directions to your heart?",
    "Well, here I am. What are your other two wishes?",
    "Hey, how was heaven when you left it?",
    "Are you my phone? Because you autocomplete me.",
    "Are you a charger? Because I'm dying without you.",
    "Wanna be Minecraft without the craft?",
    "Are you lightning? Because you're McQueen.",
    "Is there an airport nearby or is that my heart taking off?",
    "Do you have a pet? Because seeing you has given me a whole new leash on life.",
    "Is your name Jimmy? Because I've Fallon for you.",
    "I don't normally chase people but for you I'd put my crocs in sport mode.",
    "Are you a Mariah Carey song? Because All I Want for Christmas Is You.",
    "Aren't you worried about global warming? Because you're making it hot in here.",
    "If you were a triangle you'd be acute one.",
    "Are you a loan? You've got my interest.",
    "Are you a magician? Because when I look at you, everyone else disappears.",
    "Did you invent the airplane? Because you're clearly Mr. Wright.",
    "Is your dad a boxer? Because you're a knockout!",
    "How can I plan our wedding without having your number?",
    "Are you a keyboard? Because you might just be my type.",
    "You know, I'm actually terrible at flirting. How about you try to pick me up instead?",
    "4+4=8 but you+me=fate",
    "Are you tired? You've been running through my mind all day.",
    "What's your favorite drink? I'm asking so I know what to buy you when we go on our first date.",
    "I should complain to Spotify for not making you this week's hottest single.",
    "Do you play soccer? Because you're a keeper.",
    "You look so familiar…did we have class together? I could've sworn we had chemistry.",
    "I'm learning about important dates in history, wanna be one of them?",
    "They say dating is a numbers game, so can I get yours?",
    "When I text you good morning tomorrow, what number should I text?",
    "Hi, my name is [your name], but you can call me tomorrow.",
    "Can I show your profile to my friends to prove that angels really do exist?",
    "There's something wrong with my phone, it doesn't have your number in it."
        };


        private void Update()
        {
            if (this.txt == null)
            {
                this.FindMotdText();
            }
            if (this.txt != null)
            {
                this.UpdateMessage();
                this.AnimateColor();
            }
        }

        private void FindMotdText()
        {
            GameObject gameObject = GameObject.Find("COCBodyText_TitleData");
            if (gameObject != null)
            {
                this.txt = gameObject.GetComponent<TextMeshPro>();
                if (this.txt != null)
                {
                    this.txt.alignment = TextAlignmentOptions.Center;
                    this.txt.enableWordWrapping = true;
                    this.txt.enableVertexGradient = true;
                    this.txt.margin = new Vector4(0f, 0f, 0f, 100f);
                }
            }

            var display = GameObject.Find("Environment Objects/LocalObjects_Prefab/TreeRoom/COCBodyText_TitleData")?.GetComponent<PlayFabTitleDataTextDisplay>();
            if (display != null)
            {
                display.enabled = false;
            }
        }

        private void UpdateMessage()
        {
            if (this.txt != null)
            {
                this.txt.text = this.GetTodaysVerse().ToUpper();
            }
        }

        private void AnimateColor()
        {
            if (this.txt != null)
            {
                this.colorTimer += Time.deltaTime * 0.5f;
                float t = (Mathf.Sin(this.colorTimer) + 1f) / 2f;
                Color color = Color.Lerp(this.startColor, this.endColor, t);
                this.txt.colorGradient = new VertexGradient(color, color, color, color);
            }
        }

        private string GetTodaysVerse()
        {
            int index = DateTime.UtcNow.DayOfYear % this.verses.Length;
            return this.verses[index];
        }
    }
}